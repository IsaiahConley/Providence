log.info("Loading ".._ENV["!guid"]..".")
mods["RoRRModdingToolkit-RoRR_Modding_Toolkit"].auto() 
local PATH = _ENV["!plugins_mod_folder_path"]
local NAMESPACE = "BULUUARK"

local initialize = function() 
    local my_survivor = Survivor.new(BULUUARK, "Providence")
end

Initialize(initialize)




local sprites = {
        idle = Resources.sprite_load(BULUUARK, "providence_idle", path.combine(PATH, "Sprites", "IdleSheet.png"), 0, 0, 48),
        walk = Resources.sprite_load(BULUUARK, "providence_walk", path.combine(PATH, "Sprites", "WalkSheet.png"), 0, 0, 66),
        jump = Resources.sprite_load(BULUUARK, "providence_jump", path.combine(PATH, "Sprites", "Jumprise.png"), 0, 0, 69),
        jump_peak = Resources.sprite_load(BULUUARK, "providence_jump_peak", path.combine(PATH, "Sprites", "JumpPeak.png"), 0, 0, 0),
        fall = Resources.sprite_load(BULUUARK, "providence_fall", path.combine(PATH, "Sprites", "JumpFall.png"), 0, 0, 69),
        climb = Resources.sprite_load(BULUUARK, "providence_climb", path.combine(PATH, "Sprites", "Climbsheet.png"), 0, 0, 47),
        climb_hurt = Resources.sprite_load(BULUUARK, "providence_climb_hurt", path.combine(PATH, "Sprites", "Climbsheet.png"), 0, 0, 47), 
        death = Resources.sprite_load(BULUUARK, "providence_death", path.combine(PATH, "Sprites", "DieSheet.png"), 0, 0, 60),
        decoy = Resources.sprite_load(BULUUARK, "providence_decoy", path.combine(PATH, "Sprites", "IdleSheet.png"), 0, 0, 48), }
}

    local spr_atk1 = Resources.sprite_load(BULUUARK, "providence_atk1", path.combine(PATH, "Sprites", "Primary1.png"), 5, 48, 69)
    local spr_atk2 = Resources.sprite_load(BULUUARK, "providence_atk2", path.combine(PATH, "Sprites", "Primary2.png"), 5, 48, 69)
    local spr_atk3 = Resources.sprite_load(BULUUARK, "providence_atk3", path.combine(PATH, "Sprites", "Primary3.png"), 5, 48, 69)
    local spr_float = Resources.sprite_load(BULUUARK, "providence_float", path.combine(PATH, "Sprites", "Utility.png"), 6, 48, 69)
    local spr_throw = Resources.sprite_load(BULUUARK, "providence_throw", path.combine(PATH, "Sprites", "Secondary.png"), 7, 48, 69)
    local spr_orb = Resources.sprite_load(BULUUARK, "providence_orb", path.combine(PATH, "Sprites", "SecondaryProjectile.png"), 3, 6, 6, 0.25, 2, 2, 9, 9) 
    local spr_slam = Resources.sprite_load(BULUUARK, "providence_slam", path.combine(PATH, "Sprites", "Utility2.png"), 4, 6, 6, 0.25, 2, 2, 9, 9) 
    local spr_shadowf = Resources.sprite_load(BULUUARK, "providence_shadowf", path.combine(PATH, "Sprites", "Shadow.png"), 15, 48, 69)
    local spr_shadows = Resources.sprite_load(BULUUARK, "providence_shadows", path.combine(PATH, "Sprites", "Shadow2.png"), 15, 48, 69)
    local spr_conjour = Resources.sprite_load(BULUUARK, "providence_conjour", path.combine(PATH, "Sprites", "Special.png"), 15, 48, 69)
    local spr_target = Resources.sprite_load(BULUUARK, "providence_target", path.combine(PATH, "Sprites", "SpecialProjectile.png"), 15, 48, 69)
    local spr_wormhead = Resources.sprite_load(BULUUARK, "providence_wormhead", path.combine(PATH, "Sprites", "wormhead.png"), 15, 48, 69)
    local spr_wormarmour = Resources.sprite_load(BULUUARK, "providence_wormarmour", path.combine(PATH, "Sprites", "wormarmour.png"), 15, 48, 69)
    local spr_wormbelt = Resources.sprite_load(BULUUARK, "providence_wormbelt", path.combine(PATH, "Sprites", "wormbelt.png"), 15, 48, 69)
    local spr_wormnaked = Resources.sprite_load(BULUUARK, "providence_wormnaked", path.combine(PATH, "Sprites", "wormnaked.png"), 15, 48, 69)
    local spr_wormtail = Resources.sprite_load(BULUUARK, "providence_wormtail", path.combine(PATH, "Sprites", "wormtail.png"), 15, 48, 69)


    local spr_skills = Resources.sprite_load(BULUUARK, "providence_skills", path.combine(PATH, "Sprites", "Abilities.png"), 4, 0, 0) 
    local spr_portrait = Resources.sprite_load(BULUUARK, "providence_portrait", path.combine(PATH, "Sprites", "Portrait.png")) 
    local spr_portrait_cropped = Resources.sprite_load(BULUUARK, "providence_portrait_cropped", path.combine(PATH, "Sprites", "PortraitCropped.png")) 
    local spr_portrait_small = Resources.sprite_load(BULUUARK, "providence_portrait_small", path.combine(PATH, "Sprites", "SmallPortrait.png")) 
    local spr_loadout = Resources.sprite_load(BULUUARK, "providence_loadout", path.combine(PATH, "Sprites", "loadout.png"), 4, 28, 0)
    local spr_palette = Resources.spritel_load(BULUUARK, "providence_palette", path.combine(PATH, "Sprites", "palette.png"))
    local sprSelectPalette = Resources.sprite_load(BULUUARK, "select_providence_palette", path.combine(PATH, "Sprites", "selectpalette.png"))
    Providence:set_primary_color(Color.from_rgb(150, 150, 180))

    Providence.sprite_loadout = spr_loadout
    Providence.sprite_portrait = spr_portrait 
    Providence.sprite_portrait_small = spr_portrait_small
    Providence.sprite_portrait_palette = spr_portrait_cropped
    Providence.sprite_title = sprites.walk
    Providence.sprite_idle = sprites.idle
    Providence.sprite_credits = sprites.walk
    Providence.set_animations(sprites)
    Providence:set_palettes(sprPalette, sprSelectPalette, sprSelectPalette)

    Providence:set_cape_offset(-1, -1, 0, -1)
    local log = Survivor_Log.new(Providence, Providence.sprite_portrait, sprites.jump)


    Providence:set_stats_base({
        maxhp = 300
        damage = 14
        regen = 0.01
    })
    Providence:set_stats_level({
        maxhp = 25
        damage = 2
        regen = 0.002
        armor = 4
    })

    local combo_atks = {}
    combo_atks[0.0] = {
        sprite = spr_atk1,
        hstep = 2,
        box = { 27, -10, 54, 35 },
    }
    combo_atks[1.0] = {
        sprite = spr_atk2,
        hstep = 2,
        box = { 28, -14, 56, 43 },
    }
    combo_atks[2.0] = {
        sprite = spr_atk3,
        hstep = 2,
        box = { 27, -14, 54, 44 },
    }


     local obj_orb = Object.new(Buluuark, "samurai_orb")
    obj_orb.obj_sprite = spr_orb
    obj_orb.obj_depth = 1

 function shurikenStep(inst) 
        local data = inst:get_data()

        inst.x = inst.x + data.hspeed
        inst.y = inst.y + data.vspeed

        
        local actor_collisions, _ = inst:get_collisions(gm.constants.pActorCollisionBase)
        for _, actor in ipairs(actor_collisions) do
            if data.parent:attack_collision_canhit(actor) then
                -- Deal damage
                local dmg = data.damage_coeff 
                for i=1, data.clone_multiplier do -- Multiple hits per clone, boosting damage and rerolling procs
                    data.parent:fire_direct(actor, dmg, data.angle, nil, nil, gm.constants.sEfSlash)
                end
                inst:destroy()
                break
            end
        end


        local stage_width = GM._mod_room_get_current_width()
        local stage_height = GM._mod_room_get_current_height()
        if inst.x < -16 or inst.x > stage_width + 16 
           or inst.y < -16 or inst.y > stage_height + 16 
        then 
            log.info("Out of bounds")
            inst:destroy()
        end
    end

    obj_shuriken:onStep(shurikenStep)

    local skill_cut = Providence:get_primary()
    local skill_throw = Providence:get_secondary()
    local skill_slam = Providence:get_utility()
    local skill_target = Providence:get_special()

    skill_cut:set_skill_animation(spr_atk1)
    skill_throw:set_skill_animation(spr_throw)
    skill_slam:set_skill_animation(spr_float, spr_slam)
    skill_target:set_skill_animation(spr_conjour)

    local state_cut = State.new(Buluuark, skill_cut.identifier)
    local state_throw = State.new(Buluuark, skill_throw.identifier)
    local state_slam_float = State.new(Buluuark, skill_slam.identifier.."float")
    local state_slam = State.new(Buluuark, skill_float.identifier)
    local state_target = State.new(Buluuark, skill_target.identifier)

    skill_cut:set_skill_icon(spr_skills, 0)
    skill_throw:set_skill_icon(spr_skills, 1)
    skill_float:set_skill_icon(spr_skills, 2)
    skill_target:set_skill_icon(spr_skills, 3)

    skill_cut:set_skill_properties(1.5, 0)
    skill_throw:set_skill_properties(0.5, 5*60)
    skill_float:set_skill_properties(2, 8*60)
    skill_target:set_skill_properties(3, 20*60)

    samurai:onStep(function (inst) 
        local data = inst:get_data()
        if data.combo_counter == nil then data.combo_counter = 0 end
        if data.combo_hit == nil then data.combo_hit = 0 end

        if data.combo_counter > 0 then
            data.combo_counter = data.combo_counter - 1
        else 
            data.combo_hit = 0
        end
    end)

    skill_cut:onActivate(function(actor, skill, index) 
        GM.actor_set_state(actor, state_cut)
    end)

    state_cut:onEnter(function(actor, data) 
        local actor_data = actor:get_data()
        actor.image_index = 0
        data.fired = 0
        data.current_hit = math.floor(actor_data.combo_hit % 3)
        actor_data.combo_hit = actor_data.combo_hit + 1
        actor_data.combo_counter = 60 * 2 -- 2 seconds and the combo resets
    end)

    state_cut:onStep(function(actor, data) 
        actor:skill_util_fix_hspeed()
        local atk = combo_atks[data.current_hit]
        actor:actor_animation_set(atk.sprite, 0.25)

        local direction = GM.cos(GM.degtorad(actor:skill_util_facing_direction()))

        if data.fired == 0 and actor.image_index >= 2 then
            local dmg = actor:skill_get_damage(skill_cut)
            if actor:is_grounded() then
                actor.pHspeed = direction * atk.hstep
            end
            
            if not actor:skill_util_update_heaven_cracker(actor, dmg) then
                local buff_shadow_clone = Buff.find("ror", "shadowClone")
                for i=0, actor:buff_stack_count(buff_shadow_clone) do
                    local x_offset = atk.box[1] * direction
                    actor:fire_explosion(actor.x + x_offset, actor.y + atk.box[2], atk.box[3], atk.box[4], dmg, gm.constants.sNone, spr_slash_hit)
                end
            end

            actor:sound_play(gm.constants.wMercenaryShoot1_1, 1, 0.8 + math.random() * 0.2)
            data.fired = 1
        end

        actor:skill_util_exit_state_on_anim_end()
    end)
--secondaryskill
    
    skill_throw:onActivate(function(actor, skill, index) 
        GM.actor_set_state(actor, state_throw)
    end)

    state_throw:onEnter(function(actor, data) 
        actor.image_index = 0
        data.fired = 0
    end)

    state_throw:onStep(function(actor, data) 
        actor:skill_util_fix_hspeed()
        actor:actor_animation_set(actor:actor_get_skill_animation(skill_throw), 0.25)

        if data.fired == 0 and actor.image_index >= 2 then
            local dmg = actor:skill_get_damage(skill_throw)
            local orb_speed = 10
            local angle = actor:skill_util_facing_direction()
            local direction = GM.cos(GM.degtorad(angle)) 
            local spawn_x = actor.x + direction * 10
            local spawn_y = actor.y - 3
            
            -- Make the spread nice for multiple shurikens
            local spread_per_orb = 5
            
                local orb_inst = orb_obj:create(spawn_x, spawn_y)
                local orb_data = orb_inst:get_data()
                orb_data.parent = actor
                orb_data.vspeed = orb_speed * GM.sin(GM.degtorad(angle))
                orb_data.hspeed = orb_speed * GM.cos(GM.degtorad(angle))
                orb_data.damage_coeff = dmg
                orb_data.clone_multiplier = clone_stacks + 1
                orb_data.angle = angle
                angle = angle + spread_per_orb
            end

            actor:sound_play(gm.constants.wHuntressShoot1, 1, 0.8 + math.random() * 0.2)
            data.fired = 1
        end
        actor:skill_util_exit_state_on_anim_end()

    skill_parry:onActivate(function(actor, skill, index) 
        GM.actor_set_state(actor, state_parry)
    end)

    state_parry:onEnter(function(actor, data) 
        actor.image_index = 0
        data.parried = 0
        actor:set_immune(20) 
        actor:sound_play(gm.constants.wClayShoot1, 1, 0.8 + math.random() * 0.2)
    end)

    state_parry:onStep(function(actor, data) 
        actor:skill_util_fix_hspeed()
        local animation_speed = 0.25

        -- We don't want attack speed to speed up the parry itself, because that could end up
        -- reducing the parry window, so we undo its benefit ahead of time
        if actor.attack_speed > 0 then
            animation_speed = animation_speed / actor.attack_speed
        end

        actor:actor_animation_set(actor:actor_get_skill_animation(skill_parry), animation_speed)
        actor:skill_util_exit_state_on_anim_end()
    end)

   
    local net_counter_packet = Packet.create()
    net_counter_packet:onReceived(function (message, player_instance_id)
        local parry_dmg = message:read_float()
        local actor = message:read_instance()
        if actor then 
            activate_counter(actor, parry_dmg)

            -- If we're the host then we should forward this message to all the other clients
            -- except the one who initially sent it to us
            local net_type = Net.get_type()
            if net_type == Net.TYPE.host then
                local counter_msg = net_counter_packet:message_begin()
                counter_msg:write_float(parry_dmg)
                counter_msg:write_instance(actor)
                counter_msg:send_exclude(player_instance_id)
            end
        end
    end)

    function activate_counter(actor, parry_dmg) 
        local actor_data = actor:get_data()
        actor_data.parry_dmg = parry_dmg
        actor:sound_play(gm.constants.wMercenary_Parry_Deflection, 1, 0.8 + math.random() * 0.2)
        actor:enter_state(state_parry_attack)
    end

    -- Callback to enter the parry attack state when successfully blocked an attack
    parry_callback = function(actor, damager)
        local current_state = GM.actor_get_current_actor_state(actor)
        if current_state == state_parry.value then
            local state_data = GM.actor_get_actor_state_data(actor)

            if state_data.parried == 0 then
                state_data.parried = 1 -- Don't allow consecutive parries with a single usage


                local parry_dmg = damager.damage * actor:skill_get_damage(skill_parry)
                activate_counter(actor, parry_dmg)

                -- Send network message to activate the counter
                local counter_msg = net_counter_packet:message_begin()
                counter_msg:write_float(parry_dmg)
                counter_msg:write_instance(actor)
                local net_type = Net.get_type()
                if net_type == Net.TYPE.host then
                    counter_msg:send_to_all()
                elseif net_type == Net.TYPE.client then
                    counter_msg:send_to_host()
                end
            end
        end
    end

    state_parry_attack:onEnter(function(actor, data)
        -- Frame 0 is a hacky sprite to make things look good when repeatedly flipping, so we start
        -- at frame 1 instead
        actor.image_index = 1 
        data.fired = 0
        data.teleported = 0
        data.parry_direction = GM.cos(GM.degtorad(actor:skill_util_facing_direction()))

        -- Counters for repeating the attack with drunk stacks
        data.drunk_repeats = 0 
        data.total_drunk_repeats = actor:buff_stack_count(buff_drunk)
        local mega_drunk_stacks = actor:buff_stack_count(buff_mega_drunk)
        if mega_drunk_stacks > data.total_drunk_repeats then
            data.total_drunk_repeats = mega_drunk_stacks
        end

        -- Hold their initial y-position and prevent them from moving from it
        data.parry_y_position = actor.y
    end)

    state_parry_attack:onStep(function(actor, data)
        actor:skill_util_fix_hspeed()
        actor:actor_animation_set(spr_defend_counter, 0.25)

        actor.y = data.parry_y_position
        actor.pVspeed = 0.0

        -- Teleport to the end of the slash, using hspeed to maintain collision detection
        if actor.image_index >= 1 then
            if data.teleported == 0 then
                data.teleported = 1 
                local teleport_offset = data.parry_direction * 200 
                actor.pHspeed = teleport_offset
                data.parry_direction = data.parry_direction * -1
            else
                actor.pHspeed = 0
                if data.fired == 0 then
                    -- Reset cooldowns 
                    actor:refresh_skill(Skill.SLOT.primary)
                    actor:refresh_skill(Skill.SLOT.secondary)
                    actor:refresh_skill(Skill.SLOT.special)

                    -- Apply bonus immunity to prevent coming out of the attack and being insta-gibbed
                    actor:set_immune(45)

                    -- Make an explosion that deals damage around the samurai
                    local buff_shadow_clone = Buff.find("ror", "shadowClone")
                    for i=0, actor:buff_stack_count(buff_shadow_clone) do
                        local explosion_offset = data.parry_direction * 100
                        local actor_data = actor:get_data()
                        local parry_dmg = actor_data.parry_dmg

                        -- This is nil for all clients other than the player controlling this samurai
                        if parry_dmg then
                            actor:fire_explosion(actor.x + explosion_offset, actor.y - 10, 300, 20, parry_dmg, nil, spr_slash_hit)
                        end
                    end

                    actor:sound_play(gm.constants.wMercenaryShoot1_3, 1, 0.8 + math.random() * 0.2)
                    data.fired = 1
                end
            end
        end


        -- Repeat the slash for each drunk stack 
        if data.drunk_repeats < data.total_drunk_repeats and actor.image_index >= 5 then
            data.teleported = 0
            data.fired = 0
            actor.image_xscale = actor.image_xscale * -1 -- Flip the sprite
            actor.image_index = 0 -- Frame 0 is a hack to account for being flipped this frame
            data.drunk_repeats = data.drunk_repeats + 1
        end

        actor:skill_util_exit_state_on_anim_end()
    end)

    -- Special skill handlers
    skill_drink:onActivate(function(actor, skill, index) 
        GM.actor_set_state(actor, state_drink)
    end)

    state_drink:onEnter(function(actor, data) 
        actor.image_index = 0
        data.fired = 0
    end)

    state_drink:onStep(function(actor, data) 
        actor:skill_util_fix_hspeed()
        actor:actor_animation_set(actor:actor_get_skill_animation(skill_drink), 0.25)

        if data.fired == 0 and actor.image_index >= 7 then
            data.fired = 1
            actor:sound_play(gm.constants.wEgg, 1, 0.8 + math.random() * 0.2)
            local scepter = Item.find("ror", "ancientScepter")
            local has_scepter = (actor:item_stack_count(scepter) > 0)
            local drunk_stack_count = actor:buff_stack_count(buff_drunk)
            local total_stacks = drunk_stack_count
            if has_scepter then
                if drunk_stack_count > 0 then
                    actor:buff_remove(buff_drunk, drunk_stack_count)
                    actor:buff_apply(buff_mega_drunk, 30*60, drunk_stack_count)
                end

                total_stacks = actor:buff_stack_count(buff_mega_drunk)
                actor:buff_apply(buff_mega_drunk, 30*60)
            else
                actor:buff_apply(buff_drunk, 30*60)
            end

            if total_stacks >= buff_drunk.max_stack then
                local max_hp = GM.actor_get_maxhp_total(actor)
                local heal_amount = math.ceil(max_hp * 0.15)
                actor:heal(heal_amount)
            end
        end

        actor:skill_util_exit_state_on_anim_end()
    end)

    log.info("Finished initialising samurai")



if hot_reloading then
    initialise()
else 
    Initialize(initialise)
end
hot_reloading = true


